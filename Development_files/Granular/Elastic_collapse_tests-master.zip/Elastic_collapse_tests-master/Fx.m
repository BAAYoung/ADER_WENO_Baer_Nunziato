function [ F ] = Fx( U,zeta,lambda )
%UNTITLED13 Summary of this function goes here
%   Detailed explanation goes here

    h = U(:,:,1);
    u = U(:,:,2)./h;
    v = U(:,:,3)./h;
    %T = U(:,:,4)./h;
    
    alpha = 0.1;
    
    F(:,:,1) = h.*u;
    F(:,:,2) = lambda*h.*u.*u + 0.5*h.*h*cos(zeta) + U(:,:,4);
    F(:,:,3) = lambda*h.*u.*v;
    F(:,:,4) = h.*u.*U(:,:,4);
end

