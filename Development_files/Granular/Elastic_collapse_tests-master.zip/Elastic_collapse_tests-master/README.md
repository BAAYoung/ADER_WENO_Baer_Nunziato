# Elastic_collapse_tests
Scripts for testing energy cascades within the Statistical inelastic regime for granular materials
