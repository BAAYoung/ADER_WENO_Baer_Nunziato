function [ F ] = Fz( U,zeta,lambda )
%UNTITLED14 Summary of this function goes here
%   Detailed explanation goes here
    h = U(:,:,1);
    u = U(:,:,2)./h;
    v = U(:,:,3)./h;
    
    alpha = 0.1;
    
    F(:,:,1) = h.*v;
    F(:,:,3) = lambda*h.*v.*v + 0.5*h.*h*cos(zeta) + U(:,:,4)*alpha;
    F(:,:,2) = lambda*h.*u.*v;
    F(:,:,4) = U(:,:,4).*h.*v;

end

